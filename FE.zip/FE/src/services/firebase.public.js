// FE/src/services/firebase.public.js  (commit nel repo)
export const firebasePublicConfig = {
  apiKey: "AIzaSyC_bsf-LD6Iv5IaQUGzjGEbpjb4EPh4CfE",
  authDomain: "noteboard-dac65.firebaseapp.com",
  projectId: "noteboard-dac65",
  appId: "1:657976200993:web:2a0479161887bbde2f7860",
  messagingSenderId: "657976200993",
}
