export const STATUSES = ["todo", "in_progress", "done"]
export const LABELS = { todo: "To Do", in_progress: "In Progress", done: "Done" }
export const LS_KEY = "noteboard:v1"
